from setuptools import setup, find_packages

setup(name='pyspark_pipelines',
      version='0.0.1',
      description='Sample PySpark Application for use with Databricks Connect',
      url='http://github.com/magrathj',
      author='Jared Magrath',
      author_email='magrathj@tcd.ie',
      license='',
      packages=find_packages(),
      install_requires=[],
      zip_safe=False
)
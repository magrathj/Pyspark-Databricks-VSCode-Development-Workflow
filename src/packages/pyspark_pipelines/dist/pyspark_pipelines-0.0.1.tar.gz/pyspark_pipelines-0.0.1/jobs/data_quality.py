

class DataQuality:

    def get_(self):
       return 0